pimcore.registerNS('pimcore.plugin.toolbox.main');
pimcore.plugin.toolbox.main = Class.create({});

Ext.onReady(function () {
    new pimcore.plugin.toolbox.main();
});