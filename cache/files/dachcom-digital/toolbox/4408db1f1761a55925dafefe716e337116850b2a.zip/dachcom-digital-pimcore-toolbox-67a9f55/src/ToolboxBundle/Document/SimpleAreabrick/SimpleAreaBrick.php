<?php

namespace ToolboxBundle\Document\SimpleAreabrick;

use ToolboxBundle\Document\Areabrick\AbstractBaseAreabrick;

class SimpleAreaBrick extends AbstractBaseAreabrick
{
    use SimpleAreaBrickTrait;
}
