<?php

namespace ToolboxBundle\Provider;

interface StoreProviderInterface
{
    public function getValues(): array;
}
