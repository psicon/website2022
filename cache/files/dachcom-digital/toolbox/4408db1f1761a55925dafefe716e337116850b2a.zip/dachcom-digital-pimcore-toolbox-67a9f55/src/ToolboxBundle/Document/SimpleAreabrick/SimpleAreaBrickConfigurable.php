<?php

namespace ToolboxBundle\Document\SimpleAreabrick;

use ToolboxBundle\Document\Areabrick\AbstractAreabrick;

class SimpleAreaBrickConfigurable extends AbstractAreabrick
{
    use SimpleAreaBrickTrait;
}
