<?php

namespace ToolboxBundle\Resolver;

interface ContextResolverInterface
{
    public function getCurrentContextIdentifier(): ?string;
}
