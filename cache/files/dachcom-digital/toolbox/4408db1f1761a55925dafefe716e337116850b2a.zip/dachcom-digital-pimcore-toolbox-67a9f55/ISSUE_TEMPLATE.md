| Q                | A
| ---------------- | -----
| Bug report?      | yes/no
| Feature request? | yes/no
| BC Break report? | yes/no
| RFC?             | yes/no

<!--
- Please fill in this template according to your issue.
- For support request or how-tos, visit https://gitter.im/pimcore/pimcore or https://talk.pimcore.org/
- Otherwise, replace this comment by the description of your issue.
-->