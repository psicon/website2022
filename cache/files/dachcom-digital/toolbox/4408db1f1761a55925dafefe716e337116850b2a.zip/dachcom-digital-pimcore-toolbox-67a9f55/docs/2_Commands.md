# Commands
<img width="677" src="https://user-images.githubusercontent.com/700119/35486821-d8fcadb6-0473-11e8-944b-4b482e981304.png">

## Area Configuration
Use this command to get a brief overview about a given area brick.

```bash
$ bin/console toolbox:check-config --area=accordion

# use with context
$ bin/console toolbox:check-config --area=accordion --context=portal
```
