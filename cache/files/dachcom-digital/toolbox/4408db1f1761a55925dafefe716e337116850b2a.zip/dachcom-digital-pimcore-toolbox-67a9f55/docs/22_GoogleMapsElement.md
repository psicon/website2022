# Google Maps Element
Create a Google Map Element.

> Note: This element is also used in the toolbox google map element.

## Usage

```twig
{{ pimcore_googlemap('googlemap', {
        'reload' : true,
        'mapZoom' : mapZoom,
        'mapType' : mapType,
        'iwOnInit' : iwOnInit
}) }}
```