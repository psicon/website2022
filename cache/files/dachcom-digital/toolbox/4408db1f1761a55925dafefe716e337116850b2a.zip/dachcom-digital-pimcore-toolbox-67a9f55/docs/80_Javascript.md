# Javascript Plugins

## Jquery
All jQuery Extensions are available on npmjs.com via [jquery-pimcore-toolbox](https://www.npmjs.com/package/jquery-pimcore-toolbox). 

### Installation
```bash
npm i jquery-pimcore-toolbox
```

Read more about installation and usage on [github](https://github.com/dachcom-digital/jquery-pimcore-toolbox).

## Alpine.js
TBD