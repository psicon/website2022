# Overriding Views

Symfony allows to override every view and so does this Bundle.

**Important:** Never! override templates from `@Toolbox/areas/*.html.twig`, always use the views from `@Toolbox/Toolbox/[LAYOUT]/*.html.twig`.
