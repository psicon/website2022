<?php

namespace DachcomBundle\Test;

class FunctionalTester extends \Dachcom\Codeception\FunctionalTester
{
    use _generated\FunctionalTesterActions;
}
