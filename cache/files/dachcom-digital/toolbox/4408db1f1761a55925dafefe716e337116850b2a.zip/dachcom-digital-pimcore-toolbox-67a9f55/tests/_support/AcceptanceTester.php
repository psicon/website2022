<?php

namespace DachcomBundle\Test;

class AcceptanceTester extends \Dachcom\Codeception\AcceptanceTester
{
    use _generated\AcceptanceTesterActions;
}
