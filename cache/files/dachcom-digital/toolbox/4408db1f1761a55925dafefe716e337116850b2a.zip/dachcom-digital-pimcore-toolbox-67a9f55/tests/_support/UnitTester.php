<?php

namespace DachcomBundle\Test;

class UnitTester extends \Dachcom\Codeception\UnitTester
{
    use _generated\UnitTesterActions;
}
