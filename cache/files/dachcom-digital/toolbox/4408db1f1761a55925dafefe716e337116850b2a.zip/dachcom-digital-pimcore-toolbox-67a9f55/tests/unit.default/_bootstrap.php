<?php

include 'Areas/AbstractAreaTest.php';