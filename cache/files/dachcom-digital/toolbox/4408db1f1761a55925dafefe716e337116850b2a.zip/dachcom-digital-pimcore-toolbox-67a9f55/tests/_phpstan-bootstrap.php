<?php

# prevent php warnings in phpstan.
if (!defined('PIMCORE_PRIVATE_VAR')) {
    define('PIMCORE_PRIVATE_VAR', '');
}